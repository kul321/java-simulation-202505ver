package project.CoffeeShop;

public class MenuItem {

    public static final int DRINK = 0;
    public static final int FOOD = 1;

    public String name;
    public int price;
    public int type;  // 0: 음료, 1: 음식
    public Recipe recipe;

    public MenuItem(String name, int price, int type, Recipe recipe) {
        this.name = name;
        this.price = price;
        this.type = type;
        this.recipe = recipe;
    }


}
