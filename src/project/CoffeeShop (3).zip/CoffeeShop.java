package project.CoffeeShop;

import java.util.ArrayList;
import java.util.List;

public class CoffeeShop {
    public int money;
    public List<MenuItem> menuItems;
    public List<Ingredient> ingredients;
    public int dailyRevenue;
    public int totalRevenue;

    public CoffeeShop(){
        money = 5000; //초기 자금
        menuItems = new ArrayList<>();
        ingredients = new ArrayList<>();
        dailyRevenue = 0;
        totalRevenue = 0;
    }


    public void resetDailyRevenue() {
        dailyRevenue = 0;
    }

    public void removeMenuItem(int index) {
        if (index >= 1 && index <= menuItems.size()) {
            MenuItem removed = menuItems.remove(index - 1);
            System.out.println(removed.name + " 메뉴가 삭제되었습니다.");
        } else {
            System.out.println("잘못된 번호입니다.");
        }
    }

    public void addMenuItem(MenuItem item){
        menuItems.add(item);
    }

    public void addIngredient(Ingredient ingredient){
        ingredients.add(ingredient);
    }

    public void showMenu(){
        System.out.println("=== 메뉴 목록 ===");
        for (int i=0; i<menuItems.size(); i++){
            MenuItem item = menuItems.get(i);
            System.out.println((i+1) + ". " + item.name + " " + item.price + "원");

            // 레시피 출력
            System.out.println("   필요 원재료: ");
            for (RecipeItem recipeItem : item.recipe.recipeItems) {
                System.out.println("   - " + recipeItem.ingredientName + ": " + recipeItem.quantity + "개");
            }
        }
    }

    public void showIngredients(){
        System.out.println("=== 재료 목록 ===");
        for (int i = 0; i < ingredients.size(); i++) {
            Ingredient ing = ingredients.get(i);
            System.out.println((i + 1) + ". " + ing.name + " - 재고: " + ing.quantity + "개, 가격: " + ing.price + "원/개");
        }

    }
    public boolean processOrder(List<MenuItem> order) {
        // 재료가 충분한지 확인
        if (!checkIngredients(order)) {
            return false;
        }

        // 재료 소비 및 판매
        for (MenuItem item : order) {
            consumeIngredients(item);

            // 판매 금액 추가
            money += item.price;
            dailyRevenue += item.price;
            totalRevenue += item.price;
        }

        return true;
    }


    public boolean checkIngredients(List<MenuItem> order) {
        for (MenuItem item : order) {
            for (RecipeItem recipeItem : item.recipe.recipeItems) {
                boolean found = false;
                for (Ingredient ing : ingredients) {
                    if (ing.name.equals(recipeItem.ingredientName)) {
                        if (ing.quantity < recipeItem.quantity) {
                            return false;  // 재료 부족
                        }
                        found = true;
                        break;
                    }
                }

                if (!found) {
                    return false;  // 필요한 재료가 없음
                }
            }
        }
        return true;
    }

   public void consumeIngredients(MenuItem item) {
        for (RecipeItem recipeItem : item.recipe.recipeItems) {
            for (Ingredient ing : ingredients) {
                if (ing.name.equals(recipeItem.ingredientName)) {
                    ing.consumeQuantity(recipeItem.quantity);
                    break;
                }
            }
        }
    }
}
