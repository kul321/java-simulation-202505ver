package project.CoffeeShop;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Random;

public class ShopManager {

    public static Scanner sc = new Scanner(System.in);
    public static Random r = new Random();

    public CoffeeShop coffeeShop;
    public int currentDay;
    public final int MAX_DAYS = 30;
    public boolean isGameOver;
    public List<DeliveryOrder> pendingDeliveries;
    public Weather todayWeather;
    public List<Employee> totalEmployees;
    public List<Employee> workingEmployees;
    public Satisfaction satisfaction;

    public int ingredientShortageCount = 0; // 재료 부족 발생 횟수
    public int moneyShortageCount = 0;      // 자금 부족 발생 횟수
    public static final int MAX_SHORTAGE_COUNT = 3; // 최대 허용 부족 횟수

    public ShopManager() {
        coffeeShop = new CoffeeShop();
        currentDay = 1;
        isGameOver = false;
        pendingDeliveries = new ArrayList<>();
        totalEmployees = new ArrayList<>();
        workingEmployees = new ArrayList<>();
        satisfaction = new Satisfaction();
    }

    public void start() {
        System.out.println("=== 당신은 커피숍 주인입니다.===");
        System.out.println("=== 게임은 30일간 진행됩니다.===");
        System.out.println("=== 주의: 고객 만족도가 0이 되면 게임이 종료됩니다! ===");
        System.out.println("=== 재료 부족이나 자금 부족은 연속 3회까지만 허용됩니다! ===");


        // 초기 메뉴 및 원재료 설정
        initializeMenu();
        initializeIngredients();

        // 게임 루프
        while (!isGameOver && currentDay <= MAX_DAYS) {
            System.out.println("=== " + currentDay + "일차 ===");
            System.out.println("현재 자금: " + coffeeShop.money + "원");
            selectWeather(); //오늘의 날씨


            // 배달 예정인 원재료 처리
            processPendingDeliveries();

            // 오너 차례
            ownerTurn();

            if (isGameOver) break;

            // 손님 차례
            customerTurn();

            // 만족도가 0이면 게임오버
            if (satisfaction.isZero()) {
                System.out.println("=== 고객 만족도가 0이 되었습니다! ===");
                System.out.println("가게를 폐업합니다. 종료");

                isGameOver = true;
                break;
            }

            // 하루 마감
            endDay();

            currentDay++;
        }

        if (!isGameOver && currentDay > MAX_DAYS) {
            // 게임 결과 표시
            showGameResult();
        }

        askForRestart();
    }

    public void processPendingDeliveries() {
        // 삭제해야 할 배달 항목을 저장할 리스트
        List<DeliveryOrder> completedDeliveries = new ArrayList<>();
        boolean hasDelivery = false;

        for (DeliveryOrder delivery : pendingDeliveries) {
            if (delivery.deliveryDay == currentDay) {
                if (!hasDelivery) {
                    System.out.println("=== 오늘 배달된 원재료 ===");
                    hasDelivery = true;
                }

                // 재료 찾기 및 재고 추가
                for (Ingredient ing : coffeeShop.ingredients) {
                    if (ing.name.equals(delivery.ingredientName)) {
                        ing.addQuantity(delivery.quantity);
                        System.out.println(ing.name + " " + delivery.quantity + "개가 배달되었습니다.");
                        break;
                    }
                }

                // 처리 완료된 배달은 나중에 제거할 목록에 추가
                completedDeliveries.add(delivery);
            }
        }

        // 처리된 배달 제거
        pendingDeliveries.removeAll(completedDeliveries);
    }

    public void initializeMenu() {
        // 기본 메뉴 추가 (0: 음료, 1: 음식)
        // 음료 메뉴
        Recipe coldAmericanoRecipe = new Recipe();
        coldAmericanoRecipe.addIngredient("커피콩", 1);
        coldAmericanoRecipe.addIngredient("물", 1);
        coldAmericanoRecipe.addIngredient("얼음", 1);
        coffeeShop.addMenuItem(new MenuItem("아이스 아메리카노", 3500, 0, coldAmericanoRecipe));

        Recipe hotAmericanoRecipe = new Recipe();
        hotAmericanoRecipe.addIngredient("커피콩", 1);
        hotAmericanoRecipe.addIngredient("물", 1);
        coffeeShop.addMenuItem(new MenuItem("따뜻한 아메리카노", 3000, 0, hotAmericanoRecipe));

        Recipe iceLatteRecipe = new Recipe();
        iceLatteRecipe.addIngredient("커피콩", 1);
        iceLatteRecipe.addIngredient("우유", 1);
        iceLatteRecipe.addIngredient("물", 1);
        iceLatteRecipe.addIngredient("얼음", 1);
        coffeeShop.addMenuItem(new MenuItem("아이스 카페라떼", 4000, 0, iceLatteRecipe));

        Recipe hotLatteRecipe = new Recipe();
        hotLatteRecipe.addIngredient("커피콩", 1);
        hotLatteRecipe.addIngredient("우유", 1);
        hotLatteRecipe.addIngredient("물", 1);
        coffeeShop.addMenuItem(new MenuItem("따뜻한 카페라떼", 3500, 0, hotLatteRecipe));

        Recipe iceCappuccinoRecipe = new Recipe();
        iceCappuccinoRecipe.addIngredient("커피콩", 1);
        iceCappuccinoRecipe.addIngredient("우유", 1);
        iceCappuccinoRecipe.addIngredient("물", 1);
        iceCappuccinoRecipe.addIngredient("얼음", 1);
        coffeeShop.addMenuItem(new MenuItem("아이스 카푸치노", 4000, 0, iceCappuccinoRecipe));

        Recipe hotCappuccinoRecipe = new Recipe();
        hotCappuccinoRecipe.addIngredient("커피콩", 1);
        hotCappuccinoRecipe.addIngredient("우유", 1);
        hotCappuccinoRecipe.addIngredient("물", 1);
        coffeeShop.addMenuItem(new MenuItem("따뜻한 카푸치노", 3500, 0, hotCappuccinoRecipe));

        Recipe coldbrewRecipe = new Recipe();
        coldbrewRecipe.addIngredient("커피콩", 2);
        coldbrewRecipe.addIngredient("물", 2);
        coldbrewRecipe.addIngredient("얼음", 2);
        coffeeShop.addMenuItem(new MenuItem("콜드브루", 4500, 0, coldbrewRecipe));

        Recipe adeRecipe = new Recipe();
        adeRecipe.addIngredient("레몬", 1);
        adeRecipe.addIngredient("설탕", 1);
        adeRecipe.addIngredient("물", 1);
        coffeeShop.addMenuItem(new MenuItem("에이드", 4000, 0, adeRecipe));

        Recipe hotChocoRecipe = new Recipe();
        hotChocoRecipe.addIngredient("초콜릿", 1);
        hotChocoRecipe.addIngredient("우유", 1);
        hotChocoRecipe.addIngredient("물", 1);
        coffeeShop.addMenuItem(new MenuItem("핫초코", 4000, 0, hotChocoRecipe));

        Recipe iceVanillaLatteRecipe = new Recipe();
        iceVanillaLatteRecipe.addIngredient("커피콩", 1);
        iceVanillaLatteRecipe.addIngredient("바닐라시럽", 1);
        iceVanillaLatteRecipe.addIngredient("우유", 1);
        iceVanillaLatteRecipe.addIngredient("물", 1);
        iceVanillaLatteRecipe.addIngredient("얼음", 1);
        coffeeShop.addMenuItem(new MenuItem("아이스 바닐라라떼", 4500, 0, iceVanillaLatteRecipe));

        Recipe hotVanillaLatteRecipe = new Recipe();
        hotVanillaLatteRecipe.addIngredient("커피콩", 1);
        hotVanillaLatteRecipe.addIngredient("바닐라시럽", 1);
        hotVanillaLatteRecipe.addIngredient("우유", 1);
        hotVanillaLatteRecipe.addIngredient("물", 1);
        coffeeShop.addMenuItem(new MenuItem("따뜻한 바닐라라떼", 4000, 0, hotVanillaLatteRecipe));


        Recipe iceTeaRecipe = new Recipe();
        iceTeaRecipe.addIngredient("차", 1);
        iceTeaRecipe.addIngredient("얼음", 1);
        coffeeShop.addMenuItem(new MenuItem("아이스티", 3500, 0, iceTeaRecipe));

        Recipe hotEspressoRecipe = new Recipe();
        hotEspressoRecipe.addIngredient("에스프레소원두", 1);
        hotEspressoRecipe.addIngredient("물", 1);
        coffeeShop.addMenuItem(new MenuItem("핫 에스프레소", 3000, 0, hotEspressoRecipe));

        Recipe iceEspressoRecipe = new Recipe();
        iceEspressoRecipe.addIngredient("에스프레소원두", 1);
        iceEspressoRecipe.addIngredient("물", 1);
        iceEspressoRecipe.addIngredient("얼음", 1);
        coffeeShop.addMenuItem(new MenuItem("아이스 에스프레소", 3500, 0, iceEspressoRecipe));

        Recipe hotGreenTeaLatteRecipe = new Recipe();
        hotGreenTeaLatteRecipe.addIngredient("녹차가루", 1);
        hotGreenTeaLatteRecipe.addIngredient("우유", 1);
        coffeeShop.addMenuItem(new MenuItem("따뜻한 녹차라떼", 4500, 0, hotGreenTeaLatteRecipe));

        Recipe iceGreenTeaLatteRecipe = new Recipe();
        iceGreenTeaLatteRecipe.addIngredient("녹차가루", 1);
        iceGreenTeaLatteRecipe.addIngredient("우유", 1);
        iceGreenTeaLatteRecipe.addIngredient("얼음", 1);
        coffeeShop.addMenuItem(new MenuItem("녹차라떼", 5000, 0, iceGreenTeaLatteRecipe));

        // 음식 메뉴
        Recipe bagelRecipe = new Recipe();
        bagelRecipe.addIngredient("베이글반죽", 1);
        bagelRecipe.addIngredient("크림치즈", 1);
        coffeeShop.addMenuItem(new MenuItem("베이글", 4500, 1, bagelRecipe));

        Recipe sandwichRecipe = new Recipe();
        sandwichRecipe.addIngredient("빵", 2);
        sandwichRecipe.addIngredient("치즈", 1);
        sandwichRecipe.addIngredient("버터", 1);
        coffeeShop.addMenuItem(new MenuItem("샌드위치", 5500, 1, sandwichRecipe));

        Recipe hotdogRecipe = new Recipe();
        hotdogRecipe.addIngredient("빵", 1);
        hotdogRecipe.addIngredient("소시지", 1);
        hotdogRecipe.addIngredient("케찹", 1);
        hotdogRecipe.addIngredient("마요네즈", 1);
        coffeeShop.addMenuItem(new MenuItem("핫도그", 4000, 1, hotdogRecipe));
    }


    public void initializeIngredients() {
        // 초기 재료 추가
        coffeeShop.addIngredient(new Ingredient("커피콩", 5, 1500));
        coffeeShop.addIngredient(new Ingredient("물", 10, 500));
        coffeeShop.addIngredient(new Ingredient("우유", 5, 1500));
        coffeeShop.addIngredient(new Ingredient("차", 3, 1000));
        coffeeShop.addIngredient(new Ingredient("얼음", 5, 500));
        coffeeShop.addIngredient(new Ingredient("베이글반죽", 3, 1000));
        coffeeShop.addIngredient(new Ingredient("크림치즈", 3, 1500));
        coffeeShop.addIngredient(new Ingredient("소시지", 3, 1000));
        coffeeShop.addIngredient(new Ingredient("빵", 5, 500));
        coffeeShop.addIngredient(new Ingredient("케찹", 3, 500));
        coffeeShop.addIngredient(new Ingredient("마요네즈", 3, 500));
        coffeeShop.addIngredient(new Ingredient("양파", 3, 500));
        coffeeShop.addIngredient(new Ingredient("크로와상반죽", 2, 1500));
        coffeeShop.addIngredient(new Ingredient("딸기잼", 2, 2000));
        coffeeShop.addIngredient(new Ingredient("치즈", 3, 1500));
        coffeeShop.addIngredient(new Ingredient("버터", 3, 1000));
        coffeeShop.addIngredient(new Ingredient("슈크림", 2, 2000));
        coffeeShop.addIngredient(new Ingredient("고구마", 2, 1000));
        coffeeShop.addIngredient(new Ingredient("밀가루", 3, 1000));
        coffeeShop.addIngredient(new Ingredient("설탕", 3, 500));
        coffeeShop.addIngredient(new Ingredient("계란", 5, 500));
        coffeeShop.addIngredient(new Ingredient("파마산치즈", 2, 2000));
        coffeeShop.addIngredient(new Ingredient("스파게티면", 2, 1500));
        coffeeShop.addIngredient(new Ingredient("레몬", 3, 1500));
        coffeeShop.addIngredient(new Ingredient("초콜릿", 3, 2000));
        coffeeShop.addIngredient(new Ingredient("바닐라시럽", 3, 1000));
        coffeeShop.addIngredient(new Ingredient("에스프레소원두", 3, 2000));
        coffeeShop.addIngredient(new Ingredient("녹차가루", 3, 2000));
    }

    public void ownerTurn() {
        boolean turnEnd = false;

        while (!turnEnd) {
            System.out.println("\n=== 주인장 메뉴 ===");
            System.out.println("1. 메뉴 보기");
            System.out.println("2. 메뉴 추가");
            System.out.println("3. 메뉴 삭제");
            System.out.println("4. 재고 확인");
            System.out.println("5. 원재료 주문");
            System.out.println("6. 부족 재료 자동 주문");
            System.out.println("7. 직원 관리");
            System.out.println("8. 일과 시작 (손님 맞이하기)");
            System.out.println("9. 게임 종료");
            System.out.print("선택: ");

            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    coffeeShop.showMenu();
                    break;
                case 2:
                    addMenu();
                    break;
                case 3:
                    removeMenu();
                    break;
                case 4:
                    coffeeShop.showIngredients();
                    break;
                case 5:
                    orderIngredients();
                    break;
                case 6:
                    autoOrderEmergencyIngredients();
                    break;
                case 7:
                    employeeManagement();
                    break;
                case 8:
                    turnEnd = true;
                    break;
                case 9:
                    System.out.println("게임을 종료합니다.");
                    isGameOver = true;
                    return;
                default:
                    System.out.println("잘못된 선택입니다.");
            }
        }
    }

    public void employeeManagement() {
        boolean back = false;

        while (!back) {
            System.out.println("=== 직원 관리 메뉴 ===");
            System.out.println("1. 직원 목록 보기");
            System.out.println("2. 직원 고용하기");
            System.out.println("3. 직원 해고하기");
            System.out.println("4. 오늘의 근무 직원 배치");
            System.out.println("5. 돌아가기");
            System.out.print("선택: ");

            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    showEmployees();
                    break;
                case 2:
                    hireEmployee();
                    break;
                case 3:
                    fireEmployee();
                    break;
                case 4:
                    setWorkers();
                    break;
                case 5:
                    back = true;
                    break;
                default:
                    System.out.println("잘못된 선택입니다.");
            }
        }
    }

    public void addMenu() {
        System.out.print("메뉴 이름: ");
        String name = sc.nextLine();
        System.out.print("가격: ");
        int price = sc.nextInt();
        System.out.print("종류 (0: 음료, 1: 음식): ");
        int type = sc.nextInt();
        sc.nextLine();

        // 레시피 생성
        Recipe recipe = new Recipe();

        System.out.println("필요한 원재료를 입력하세요 (완료 시 '완료' 입력)");
        while (true) {
            System.out.print("원재료 이름 (완료 시 '완료' 입력): ");
            String ingredientName = sc.nextLine();

            if (ingredientName.equals("완료")) {
                break;
            }

            System.out.print("필요 수량: ");
            int quantity = sc.nextInt();
            sc.nextLine();

            recipe.addIngredient(ingredientName, quantity);
        }

        MenuItem newItem = new MenuItem(name, price, type, recipe);
        coffeeShop.addMenuItem(newItem);

        System.out.println(name + " 메뉴가 추가되었습니다.");
    }

    public void removeMenu() {
        coffeeShop.showMenu();
        System.out.print("삭제할 메뉴 번호: ");
        int index = sc.nextInt();
        sc.nextLine();

        coffeeShop.removeMenuItem(index);
    }

    public void orderIngredients() {
        coffeeShop.showIngredients();
        System.out.print("주문할 재료 번호: ");
        int index = sc.nextInt();
        System.out.print("주문할 수량: ");
        int quantity = sc.nextInt();
        sc.nextLine();

        if (index >= 1 && index <= coffeeShop.ingredients.size()) {
            Ingredient ing = coffeeShop.ingredients.get(index - 1);
            double cost = ing.price * quantity;

            if (coffeeShop.money >= cost) {
                // 다음날 배달 예약
                int deliveryDay = currentDay + 1;
                DeliveryOrder newDelivery = new DeliveryOrder(deliveryDay, ing.name, quantity);
                pendingDeliveries.add(newDelivery);

                coffeeShop.money -= cost;
                System.out.println(ing.name + " " + quantity + "개를 주문했습니다. 비용: " + cost + "원");
                System.out.println("다음날 배달됩니다.");
                System.out.println("남은 자금: " + coffeeShop.money + "원");

                // 자금 검사
                if (coffeeShop.money <= 0) {
                    System.out.println("자금이 부족합니다!");
                    isGameOver = true;
                }
            }
            if (coffeeShop.money < cost) {
                System.out.println("자금이 부족합니다!");
            }
        } else {
            System.out.println("잘못된 번호입니다.");
        }

    }


    public void customerTurn() {
        int baseCustomerCount = r.nextInt(16) + 5;  // 기본 손님수 5~20

        // 날씨와 만족도 모두 반영한 최종 손님 수 계산
        double weatherMultiplier = todayWeather.customerMultiplier;
        double satisfactionMultiplier = satisfaction.getCustomerMultiplier();
        int customerCount = (int)(baseCustomerCount * weatherMultiplier * satisfactionMultiplier);

        System.out.println("오늘 방문한 손님 수: " + customerCount);
        System.out.println("오늘의 날씨: " + todayWeather.name + " (손님 배율: " + String.format("%.2f", weatherMultiplier) + ")");
        System.out.println("가게 만족도: " + satisfaction.satisfaction + " (손님 배율: " + String.format("%.2f", satisfactionMultiplier) + ")");

        for (int i = 1; i <= customerCount; i++) {
            if (isGameOver) break;

            Customer customer = new Customer(todayWeather);
            System.out.println("\n=== 손님 " + i + " ===");

            // 손님 주문 처리
            List<MenuItem> customerOrder = customer.order(coffeeShop.menuItems);

            if (customerOrder.isEmpty()) {
                System.out.println("손님이 아무것도 주문하지 않았습니다.");
                continue;
            }

            // 주문 내역 출력
            displayOrder(customerOrder);

            // 손님 메뉴
            boolean cancelOrder = processCustomerMenu(customerOrder);

            if (cancelOrder) {
                System.out.println("주문이 취소되었습니다.");
                satisfaction.decreaseSatisfaction(1);
                continue;
            }

            // 재료 확인
            if (!coffeeShop.checkIngredients(customerOrder)) {
                System.out.println("재료가 부족하여 주문을 처리할 수 없습니다!");

                // 재료 부족 카운트 증가
                ingredientShortageCount++;

                // 만족도 감소
                satisfaction.decreaseSatisfaction(5);

                // 재료 부족 경고
                System.out.println("재료 부족 발생 (" + ingredientShortageCount + "/" + MAX_SHORTAGE_COUNT + "회)");

                // 최대 허용 횟수 초과 시 게임오버
                if (ingredientShortageCount >= MAX_SHORTAGE_COUNT) {
                    System.out.println("연속 " + MAX_SHORTAGE_COUNT + "회 동안 재료 부족으로 주문을 거절했습니다!");
                    System.out.println("가게 평판이 나빠져 폐업합니다.");
                    isGameOver = true;
                    return;
                }

                continue;
            } else {
                // 재료가 충분하면 카운트 리셋
                ingredientShortageCount = 0;
            }

            // 직원 처리 로직
            double processingTime = 0;
            if (!workingEmployees.isEmpty()) {
                // 가장 빠른 직원 찾기
                Employee fastestEmployee = null;
                double bestTime = Double.MAX_VALUE;

                for (Employee emp : workingEmployees) {
                    // 각 메뉴별 처리 시간 계산
                    double employeeTime = 0;
                    for (MenuItem item : customerOrder) {
                        employeeTime += emp.processingTime(item);
                    }

                    // 더 빠른 직원 선택
                    if (employeeTime < bestTime) {
                        bestTime = employeeTime;
                        fastestEmployee = emp;
                    }
                }

                processingTime = bestTime;
                System.out.println(fastestEmployee.name + "(" + fastestEmployee.getTypeName() +
                        ")이(가) 주문을 처리합니다. 소요 시간: " + String.format("%.1f", processingTime) + "분");
            } else {
                // 직원이 없으면 주인이 직접 처리 (기본 처리 시간 적용)
                processingTime = customerOrder.size() * 2.0;  // 메뉴 당 2분 소요
                System.out.println("주인이 직접 주문을 처리합니다. 소요 시간: " + String.format("%.1f", processingTime) + "분");
            }

            // 만족도 변화 계산 및 적용
            int satisfactionChange = satisfaction.processSatisfaciton(processingTime, customerOrder);

            if (satisfactionChange > 0) {
                satisfaction.increaseSatisfaction(satisfactionChange);
            } else if (satisfactionChange < 0) {
                satisfaction.decreaseSatisfaction(Math.abs(satisfactionChange));
            }

            // 재료 소비 및 판매
            coffeeShop.processOrder(customerOrder);
            System.out.println("주문이 완료되었습니다.");
        }
    }


    public void displayOrder(List<MenuItem> order) {
        System.out.println("손님 주문 내역:");
        int totalPrice = 0;
        for (MenuItem item : order) {
            System.out.println("- " + item.name + " (" + item.price + "원)");
            totalPrice += item.price;
        }
        System.out.println("총 금액: " + totalPrice + "원");
    }


    public boolean processCustomerMenu(List<MenuItem> order) {
        System.out.println("== 손님 메뉴 ===");
        System.out.println("1. 주문 확인하기");
        System.out.println("2. 주문 취소하기");
        System.out.print("선택: ");

        int choice = sc.nextInt();
        sc.nextLine();

        return choice == 2;
    }

    public void endDay() {
        System.out.println("\n=== " + currentDay + "일차 영업 종료 ===");
        System.out.println("오늘의 매출: " + coffeeShop.dailyRevenue + "원");

        // 직원 급여 지급
        if (!workingEmployees.isEmpty()) {
            System.out.println("\n직원 급여를 지급합니다.");
            payEmployeeSalaries();
        }

        System.out.println("현재 자금: " + coffeeShop.money + "원");
        System.out.println("현재 만족도: " + satisfaction.satisfaction);

        // 일일 매출 초기화
        coffeeShop.resetDailyRevenue();

        System.out.println("계속하려면 엔터를 누르세요.");
        sc.nextLine();


    }

    // 자동 재료 주문 기능 추가 (단순화된 버전)
    public void autoOrderEmergencyIngredients() {
        System.out.println("=== 재료 부족 방지 시스템 ===");

        boolean orderedSomething = false;
        double totalCost = 0;

        // 재고가 적은 재료 표시
        System.out.println("현재 재고가 2개 이하인 재료들:");
        for (Ingredient ing : coffeeShop.ingredients) {
            if (ing.quantity <= 2) {
                System.out.println("- " + ing.name + " (현재: " + ing.quantity + "개)");
            }
        }

        // 재고가 2개 이하인 모든 재료 자동 주문
        for (Ingredient ing : coffeeShop.ingredients) {
            if (ing.quantity <= 2) {
                int orderQuantity = 5; // 기본 5개씩 주문
                double cost = ing.price * orderQuantity;

                // 자금 확인
                if (coffeeShop.money >= cost) {
                    // 다음날 배달 예약
                    int deliveryDay = currentDay + 1;
                    DeliveryOrder newDelivery = new DeliveryOrder(deliveryDay, ing.name, orderQuantity);
                    pendingDeliveries.add(newDelivery);

                    coffeeShop.money -= cost;
                    totalCost += cost;

                    System.out.println(ing.name + " " + orderQuantity + "개 주문 완료 (비용: " + cost + "원)");
                    orderedSomething = true;
                } else {
                    System.out.println(ing.name + "를 주문하기에 자금이 부족합니다.");
                }
            }
        }

        if (orderedSomething) {
            System.out.println("총 " + totalCost + "원 어치 재료를 주문했습니다.");
            System.out.println("남은 자금: " + coffeeShop.money + "원");
        } else {
            System.out.println("재고가 부족한 재료가 없거나 자금이 부족합니다.");
        }
    }

    public void showGameResult() {
        System.out.println("\n=== 게임 결과 ===");
        System.out.println("30일 동안 커피숍을 성공적으로 운영했습니다!");
        System.out.println("최종 자금: " + coffeeShop.money + "원");
        System.out.println("최종 만족도: " + satisfaction.satisfaction );
        System.out.println("총 매출: " + coffeeShop.totalRevenue + "원");
    }

    public void askForRestart() {
        System.out.print("\n게임을 다시 시작하시겠습니까? (y/n): ");
        String answer = sc.nextLine();

        if (answer.equals("y")) {
            currentDay = 1;
            isGameOver = false;
            coffeeShop = new CoffeeShop();
            pendingDeliveries = new ArrayList<>();
            start();
        } else {
            System.out.println("게임을 종료합니다. 이용해주셔서 감사합니다!");
        }
    }

    public void selectWeather(){
        int weatherType = r.nextInt(6);
        todayWeather = new Weather(weatherType);
        System.out.println("오늘의 날씨: " + todayWeather.name);
    }

    public void showEmployees(){
        if(totalEmployees.isEmpty()){
            System.out.println("고용된 직원이 없습니다.");
            return;
        }

        for(int i = 0; i<totalEmployees.size(); i++){
            Employee emp = totalEmployees.get(i);
            System.out.println((i+1)+". " + emp + (emp.isWorking ? "[근무중]" : "[OOO]"));
        }
    }

    public void hireEmployee() {
        System.out.println("새 직원 고용");

        // 지원자 생성
        List<Employee> applicants = new ArrayList<>();
        String[] names = {"가나", "다라", "마바", "사아", "자차", "카타", "파하"};

        for (int i = 0; i < 4; i++) {
            String name = names[r.nextInt(names.length)] + (i + 1);  // 이름 중복 방지
            int type = r.nextInt(5);  // 직원 타입 (0-4)
            int speedSkill = r.nextInt(5) + 1;  // 속도 스킬 (1-5)
            applicants.add(new Employee(name, type, speedSkill));  // 수정된 부분
        }

        System.out.println("상기 지원자 중에서 선택하세요");
        for (int i = 0; i < applicants.size(); i++) {
            Employee emp = applicants.get(i);
            System.out.println((i + 1) + ". " + emp.name + " - 유형: " + emp.getTypeName() +
                    ", 속도 스킬: " + emp.speedSkill + ", 급여: " + emp.salary + "원");
        }

        System.out.print("고용할 직원 번호 (취소: 0): ");
        int choice = sc.nextInt();
        sc.nextLine();

        if (choice > 0 && choice <= applicants.size()) {
            Employee hired = applicants.get(choice - 1);

            // 고용 비용 확인
            if (coffeeShop.money >= hired.salary) {
                totalEmployees.add(hired);
                coffeeShop.money -= hired.salary;  // 고용 비용 지불
                System.out.println(hired.name + "(" + hired.getTypeName() + ")을(를) 고용했습니다.");
                System.out.println("남은 자금: " + coffeeShop.money + "원");
            } else {
                System.out.println("자금이 부족하여 직원을 고용할 수 없습니다.");
            }
        } else if (choice != 0) {
            System.out.println("잘못된 번호입니다.");
        } else {
            System.out.println("고용을 취소했습니다.");
        }
    }

    public void fireEmployee() {
        if (totalEmployees.isEmpty()) {
            System.out.println("고용된 직원이 없습니다.");
            return;
        }

        System.out.println("=== 직원 해고 ===");
        showEmployees();

        System.out.print("해고할 직원 번호 (취소: 0): ");
        int choice = sc.nextInt();
        sc.nextLine();

        if (choice > 0 && choice <= totalEmployees.size()) {
            Employee fired = totalEmployees.get(choice - 1);

            // 근무 중인 직원이라면 근무 목록에서도 제거
            if (fired.isWorking) {
                workingEmployees.remove(fired);
            }

            totalEmployees.remove(choice - 1);
            System.out.println(fired.name + "(" + fired.getTypeName() + ")을(를) 해고했습니다.");

            // 해고 시 만족도 감소 (직원들의 사기가 떨어짐)
            satisfaction.decreaseSatisfaction(5);
            System.out.println("직원 해고로 가게 만족도가 감소했습니다. 현재 만족도: " + satisfaction.satisfaction);
        } else if (choice != 0) {
            System.out.println("잘못된 번호입니다.");
        } else {
            System.out.println("해고를 취소했습니다.");
        }
    }



    public void setWorkers() {
        System.out.println("=== 오늘의 근무 직원 배치 ===");

        // 현재 근무 중인 직원 모두 해제
        for (Employee emp : totalEmployees) {
            emp.setWorking(false);
        }
        workingEmployees.clear();

        // 고용된 직원 목록 표시
        System.out.println("고용된 직원 목록:");
        showEmployees();

        if (totalEmployees.isEmpty()) {
            System.out.println("고용된 직원이 없습니다.");
            return;
        }

        System.out.println("근무할 직원 번호를 입력하세요 (완료 시 0 입력)");
        while (true) {
            System.out.print("직원 번호 (완료: 0): ");
            int choice = sc.nextInt();
            sc.nextLine();

            if (choice == 0) {
                break;
            }

            if (choice > 0 && choice <= totalEmployees.size()) {
                Employee selected = totalEmployees.get(choice - 1);

                if (selected.isWorking) {
                    System.out.println(selected.name + "은(는) 이미 근무 중입니다.");
                } else {
                    selected.setWorking(true);
                    workingEmployees.add(selected);
                    System.out.println(selected.name + "을(를) 근무 배치했습니다.");
                }
            } else {
                System.out.println("잘못된 번호입니다.");
            }
        }

        System.out.println("오늘 근무 직원 (" + workingEmployees.size() + "명):");
        for (Employee emp : workingEmployees) {
            System.out.println("- " + emp.name + " (" + emp.getTypeName() + ")");
        }
    }

    public void payEmployeeSalaries() {
        if (workingEmployees.isEmpty()) {
            System.out.println("오늘 근무한 직원이 없으므로 급여를 지급하지 않습니다.");
            return;
        }

        int totalSalary = 0;
        System.out.println("=== 일일 급여 지급 ===");

        for (Employee emp : workingEmployees) {
            totalSalary += emp.salary;
            System.out.println(emp.name + " (" + emp.getTypeName() + "): " + emp.salary + "원");
        }

        if (coffeeShop.money >= totalSalary) {
            coffeeShop.money -= totalSalary;
            System.out.println("총 급여: " + totalSalary + "원 지급 완료");
            System.out.println("남은 자금: " + coffeeShop.money + "원");

            // 급여 지급으로 만족도 소폭 상승
            satisfaction.increaseSatisfaction(2);
        } else {
            System.out.println("자금 부족으로 급여를 지급할 수 없습니다!");
            System.out.println("필요 금액: " + totalSalary + "원, 보유 자금: " + coffeeShop.money + "원");

            // 급여 미지급으로 만족도 대폭 하락
            satisfaction.decreaseSatisfaction(15);
            System.out.println("급여 미지급으로 가게 만족도가 하락했습니다. 현재 만족도: " + satisfaction.satisfaction);

        }
    }
}

