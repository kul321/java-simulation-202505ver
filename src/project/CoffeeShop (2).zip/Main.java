package project.CoffeeShop;

public class Main {

    public static void main(String[] args){
    ShopManager shopManager = new ShopManager();

     shopManager.start();
    }
}
