package project.CoffeeShop;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Random;

public class ShopManager {

    public static Scanner sc = new Scanner(System.in);
    public static Random r = new Random();

    public CoffeeShop coffeeShop;
    public int currentDay;
    public final int MAX_DAYS = 30;
    public boolean isGameOver;
    public List<DeliveryOrder> pendingDeliveries;
    public Weather todayWeather;


    public ShopManager() {
        coffeeShop = new CoffeeShop();
        currentDay = 1;
        isGameOver = false;
        pendingDeliveries = new ArrayList<>();
    }

    public void start() {
        System.out.println("=== 당신은 커피숍 주인입니다.===");
        System.out.println("=== 게임은 30일간 진행됩니다.===");


        // 초기 메뉴 및 원재료 설정
        initializeMenu();
        initializeIngredients();

        // 게임 루프
        while (!isGameOver && currentDay <= MAX_DAYS) {
            System.out.println("=== " + currentDay + "일차 ===");
            System.out.println("현재 자금: " + coffeeShop.money + "원");
            selectWeather(); //오늘의 날씨



            // 배달 예정인 원재료 처리
            processPendingDeliveries();

            // 오너 차례
            ownerTurn();

            if (isGameOver) break;

            // 손님 차례
            customerTurn();

            // 하루 마감
            endDay();

            currentDay++;
        }

        if (!isGameOver && currentDay > MAX_DAYS) {
            // 게임 결과 표시
            showGameResult();
        }

        askForRestart();
    }

    public void processPendingDeliveries() {
        // 삭제해야 할 배달 항목을 저장할 리스트
        List<DeliveryOrder> completedDeliveries = new ArrayList<>();
        boolean hasDelivery = false;

        for (DeliveryOrder delivery : pendingDeliveries) {
            if (delivery.deliveryDay == currentDay) {
                if (!hasDelivery) {
                    System.out.println("=== 오늘 배달된 원재료 ===");
                    hasDelivery = true;
                }

                // 재료 찾기 및 재고 추가
                for (Ingredient ing : coffeeShop.ingredients) {
                    if (ing.name.equals(delivery.ingredientName)) {
                        ing.addQuantity(delivery.quantity);
                        System.out.println(ing.name + " " + delivery.quantity + "개가 배달되었습니다.");
                        break;
                    }
                }

                // 처리 완료된 배달은 나중에 제거할 목록에 추가
                completedDeliveries.add(delivery);
            }
        }

        // 처리된 배달 제거
        pendingDeliveries.removeAll(completedDeliveries);
    }

    public void initializeMenu() {
        // 기본 메뉴 추가 (0: 음료, 1: 음식)
        // 음료 메뉴
        Recipe coldAmericanoRecipe = new Recipe();
        coldAmericanoRecipe.addIngredient("커피콩", 1);
        coldAmericanoRecipe.addIngredient("물", 1);
        coldAmericanoRecipe.addIngredient("얼음", 1);
        coffeeShop.addMenuItem(new MenuItem("아이스 아메리카노", 3500, 0, coldAmericanoRecipe));

        Recipe hotAmericanoRecipe = new Recipe();
        hotAmericanoRecipe.addIngredient("커피콩", 1);
        hotAmericanoRecipe.addIngredient("물", 1);
        coffeeShop.addMenuItem(new MenuItem("따뜻한 아메리카노", 3000, 0, hotAmericanoRecipe));

        Recipe iceLatteRecipe = new Recipe();
        iceLatteRecipe.addIngredient("커피콩", 1);
        iceLatteRecipe.addIngredient("우유", 1);
        iceLatteRecipe.addIngredient("물", 1);
        coldAmericanoRecipe.addIngredient("얼음", 1);
        coffeeShop.addMenuItem(new MenuItem("아이스 카페라떼", 4000, 0, iceLatteRecipe));

        Recipe hotLatteRecipe = new Recipe();
        hotLatteRecipe.addIngredient("커피콩", 1);
        hotLatteRecipe.addIngredient("우유", 1);
        hotLatteRecipe.addIngredient("물", 1);
        coffeeShop.addMenuItem(new MenuItem("따뜻한 카페라떼", 3500, 0, hotLatteRecipe));

        Recipe iceCappuccinoRecipe = new Recipe();
        iceCappuccinoRecipe.addIngredient("커피콩", 1);
        iceCappuccinoRecipe.addIngredient("우유", 1);
        iceCappuccinoRecipe.addIngredient("물", 1);
        iceCappuccinoRecipe.addIngredient("얼음", 1);
        coffeeShop.addMenuItem(new MenuItem("아이스 카푸치노", 4000, 0, iceCappuccinoRecipe));

        Recipe hotCappuccinoRecipe = new Recipe();
        hotCappuccinoRecipe.addIngredient("커피콩", 1);
        hotCappuccinoRecipe.addIngredient("우유", 1);
        hotCappuccinoRecipe.addIngredient("물", 1);
        coffeeShop.addMenuItem(new MenuItem("따뜻한 카푸치노", 3500, 0, hotCappuccinoRecipe));

        Recipe coldbrewRecipe = new Recipe();
        coldbrewRecipe.addIngredient("커피콩", 2);
        coldbrewRecipe.addIngredient("물", 2);
        coldbrewRecipe.addIngredient("얼음", 2);
        coffeeShop.addMenuItem(new MenuItem("콜드브루", 4500, 0, coldbrewRecipe));

        Recipe adeRecipe = new Recipe();
        adeRecipe.addIngredient("레몬", 1);
        adeRecipe.addIngredient("설탕", 1);
        adeRecipe.addIngredient("물", 1);
        coffeeShop.addMenuItem(new MenuItem("에이드", 4000, 0, adeRecipe));

        Recipe hotChocoRecipe = new Recipe();
        hotChocoRecipe.addIngredient("초콜릿", 1);
        hotChocoRecipe.addIngredient("우유", 1);
        hotChocoRecipe.addIngredient("물", 1);
        coffeeShop.addMenuItem(new MenuItem("핫초코", 4000, 0, hotChocoRecipe));

        Recipe iceVanillaLatteRecipe = new Recipe();
        iceVanillaLatteRecipe.addIngredient("커피콩", 1);
        iceVanillaLatteRecipe.addIngredient("바닐라시럽", 1);
        iceVanillaLatteRecipe.addIngredient("우유", 1);
        iceVanillaLatteRecipe.addIngredient("물", 1);
        iceVanillaLatteRecipe.addIngredient("얼음", 1);
        coffeeShop.addMenuItem(new MenuItem("아이스 바닐라라떼", 4500, 0, iceVanillaLatteRecipe));

        Recipe hotVanillaLatteRecipe = new Recipe();
        hotVanillaLatteRecipe.addIngredient("커피콩", 1);
        hotVanillaLatteRecipe.addIngredient("바닐라시럽", 1);
        hotVanillaLatteRecipe.addIngredient("우유", 1);
        hotVanillaLatteRecipe.addIngredient("물", 1);
        coffeeShop.addMenuItem(new MenuItem("따뜻한 바닐라라떼", 4000, 0, hotVanillaLatteRecipe));


        Recipe iceTeaRecipe = new Recipe();
        iceTeaRecipe.addIngredient("차", 1);
        iceTeaRecipe.addIngredient("얼음", 1);
        coffeeShop.addMenuItem(new MenuItem("아이스티", 3500, 0, iceTeaRecipe));

        Recipe hotEspressoRecipe = new Recipe();
        hotEspressoRecipe.addIngredient("에스프레소원두", 1);
        hotEspressoRecipe.addIngredient("물", 1);
        coffeeShop.addMenuItem(new MenuItem("핫 에스프레소", 3000, 0, hotEspressoRecipe));

        Recipe iceEspressoRecipe = new Recipe();
        iceEspressoRecipe.addIngredient("에스프레소원두", 1);
        iceEspressoRecipe.addIngredient("물", 1);
        iceEspressoRecipe.addIngredient("얼음", 1);
        coffeeShop.addMenuItem(new MenuItem("아이스 에스프레소", 3500, 0, iceEspressoRecipe));

        Recipe hotGreenTeaLatteRecipe = new Recipe();
        hotGreenTeaLatteRecipe.addIngredient("녹차가루", 1);
        hotGreenTeaLatteRecipe.addIngredient("우유", 1);
        coffeeShop.addMenuItem(new MenuItem("따뜻한 녹차라떼", 4500, 0, hotGreenTeaLatteRecipe));

        Recipe iceGreenTeaLatteRecipe = new Recipe();
        iceGreenTeaLatteRecipe.addIngredient("녹차가루", 1);
        iceGreenTeaLatteRecipe.addIngredient("우유", 1);
        iceGreenTeaLatteRecipe.addIngredient("얼음", 1);
        coffeeShop.addMenuItem(new MenuItem("녹차라떼", 5000, 0, iceGreenTeaLatteRecipe));

        // 음식 메뉴
        Recipe bagelRecipe = new Recipe();
        bagelRecipe.addIngredient("베이글반죽", 1);
        bagelRecipe.addIngredient("크림치즈", 1);
        coffeeShop.addMenuItem(new MenuItem("베이글", 4500, 1, bagelRecipe));

        Recipe sandwichRecipe = new Recipe();
        sandwichRecipe.addIngredient("빵", 2);
        sandwichRecipe.addIngredient("치즈", 1);
        sandwichRecipe.addIngredient("버터", 1);
        coffeeShop.addMenuItem(new MenuItem("샌드위치", 5500, 1, sandwichRecipe));

        Recipe hotdogRecipe = new Recipe();
        hotdogRecipe.addIngredient("빵", 1);
        hotdogRecipe.addIngredient("소시지", 1);
        hotdogRecipe.addIngredient("케찹", 1);
        hotdogRecipe.addIngredient("마요네즈", 1);
        coffeeShop.addMenuItem(new MenuItem("핫도그", 4000, 1, hotdogRecipe));
    }


    public void initializeIngredients() {
        // 초기 재료 추가
        coffeeShop.addIngredient(new Ingredient("커피콩", 5, 1500));
        coffeeShop.addIngredient(new Ingredient("물", 10, 500));
        coffeeShop.addIngredient(new Ingredient("우유", 5, 1500));
        coffeeShop.addIngredient(new Ingredient("차", 3, 1000));
        coffeeShop.addIngredient(new Ingredient("얼음", 5, 500));
        coffeeShop.addIngredient(new Ingredient("베이글반죽", 3, 1000));
        coffeeShop.addIngredient(new Ingredient("크림치즈", 3, 1500));
        coffeeShop.addIngredient(new Ingredient("소시지", 3, 1000));
        coffeeShop.addIngredient(new Ingredient("빵", 5, 500));
        coffeeShop.addIngredient(new Ingredient("케찹", 3, 500));
        coffeeShop.addIngredient(new Ingredient("마요네즈", 3, 500));
        coffeeShop.addIngredient(new Ingredient("양파", 3, 500));
        coffeeShop.addIngredient(new Ingredient("크로와상반죽", 2, 1500));
        coffeeShop.addIngredient(new Ingredient("딸기잼", 2, 2000));
        coffeeShop.addIngredient(new Ingredient("치즈", 3, 1500));
        coffeeShop.addIngredient(new Ingredient("버터", 3, 1000));
        coffeeShop.addIngredient(new Ingredient("슈크림", 2, 2000));
        coffeeShop.addIngredient(new Ingredient("고구마", 2, 1000));
        coffeeShop.addIngredient(new Ingredient("밀가루", 3, 1000));
        coffeeShop.addIngredient(new Ingredient("설탕", 3, 500));
        coffeeShop.addIngredient(new Ingredient("계란", 5, 500));
        coffeeShop.addIngredient(new Ingredient("파마산치즈", 2, 2000));
        coffeeShop.addIngredient(new Ingredient("스파게티면", 2, 1500));
        coffeeShop.addIngredient(new Ingredient("레몬", 3, 1500));
        coffeeShop.addIngredient(new Ingredient("초콜릿", 3, 2000));
        coffeeShop.addIngredient(new Ingredient("바닐라시럽", 3, 1000));
        coffeeShop.addIngredient(new Ingredient("에스프레소원두", 3, 2000));
        coffeeShop.addIngredient(new Ingredient("녹차가루", 3, 2000));
    }

    public void ownerTurn() {
        boolean turnEnd = false;

        while (!turnEnd) {
            System.out.println("=== 주인장 메뉴 ===");
            System.out.println("1. 메뉴 보기");
            System.out.println("2. 메뉴 추가");
            System.out.println("3. 메뉴 삭제");
            System.out.println("4. 재고 확인");
            System.out.println("5. 원재료 주문");
            System.out.println("6. 일과 시작 (손님 맞이하기)");
            System.out.println("7. 게임 종료");
            System.out.print("선택: ");

            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    coffeeShop.showMenu();
                    break;
                case 2:
                    addMenu();
                    break;
                case 3:
                    removeMenu();
                    break;
                case 4:
                    coffeeShop.showIngredients();
                    break;
                case 5:
                    orderIngredients();
                    break;
                case 6:
                    turnEnd = true;
                    break;
                case 7:
                    System.out.println("게임을 종료합니다.");
                    isGameOver = true;
                    return;
                default:
                    System.out.println("잘못된 선택입니다.");
            }
        }
    }

    public void addMenu() {
        System.out.print("메뉴 이름: ");
        String name = sc.nextLine();
        System.out.print("가격: ");
        int price = sc.nextInt();
        System.out.print("종류 (0: 음료, 1: 음식): ");
        int type = sc.nextInt();
        sc.nextLine();

        // 레시피 생성
        Recipe recipe = new Recipe();

        System.out.println("필요한 원재료를 입력하세요 (완료 시 '완료' 입력)");
        while (true) {
            System.out.print("원재료 이름 (완료 시 '완료' 입력): ");
            String ingredientName = sc.nextLine();

            if (ingredientName.equals("완료")) {
                break;
            }

            System.out.print("필요 수량: ");
            int quantity = sc.nextInt();
            sc.nextLine();

            recipe.addIngredient(ingredientName, quantity);
        }

        MenuItem newItem = new MenuItem(name, price, type, recipe);
        coffeeShop.addMenuItem(newItem);

        System.out.println(name + " 메뉴가 추가되었습니다.");
    }

    public void removeMenu() {
        coffeeShop.showMenu();
        System.out.print("삭제할 메뉴 번호: ");
        int index = sc.nextInt();
        sc.nextLine();

        coffeeShop.removeMenuItem(index);
    }

    public void orderIngredients() {
        coffeeShop.showIngredients();
        System.out.print("주문할 재료 번호: ");
        int index = sc.nextInt();
        System.out.print("주문할 수량: ");
        int quantity = sc.nextInt();
        sc.nextLine();

        if (index >= 1 && index <= coffeeShop.ingredients.size()) {
            Ingredient ing = coffeeShop.ingredients.get(index - 1);
            double cost = ing.price * quantity;

            if (coffeeShop.money >= cost) {
                // 다음날 배달 예약
                int deliveryDay = currentDay + 1;
                DeliveryOrder newDelivery = new DeliveryOrder(deliveryDay, ing.name, quantity);
                pendingDeliveries.add(newDelivery);

                coffeeShop.money -= cost;
                System.out.println(ing.name + " " + quantity + "개를 주문했습니다. 비용: " + cost + "원");
                System.out.println("다음날 배달됩니다.");
                System.out.println("남은 자금: " + coffeeShop.money + "원");

                // 자금 검사
                if (coffeeShop.money <= 0) {
                    System.out.println("자금이 부족합니다!");
                    isGameOver = true;
                }
            }
            if (coffeeShop.money < cost) {
                System.out.println("자금이 부족합니다!");
            }
        }
            else {
                System.out.println("잘못된 번호입니다.");
            }

    }


    public void customerTurn() {

        int baseCustomerCount = r.nextInt(16) + 5;  // 기본 손님수 5~20
        int customerCount = (int)(baseCustomerCount * todayWeather.customerMultiplier);
        System.out.println("오늘 방문한 손님 수: " + customerCount);

        //테스트
        System.out.println("오늘의 날씨"+todayWeather.name+"(으)로 인한 손님수 배율: "+ todayWeather.customerMultiplier);

        for (int i = 1; i <= customerCount; i++) {
            if (isGameOver) break;

            Customer customer = new Customer(todayWeather);
            System.out.println("=== 손님 " + i + " ===");

            // 손님 주문 처리
            List<MenuItem> customerOrder = customer.order(coffeeShop.menuItems);

            if (customerOrder.isEmpty()) {
                System.out.println("손님이 아무것도 주문하지 않았습니다.");
                continue;
            }

            // 주문 내역 출력
            displayOrder(customerOrder);

            // 손님 메뉴
            boolean cancelOrder = processCustomerMenu(customerOrder);

            if (!cancelOrder) {
                // 재료 소비 및 판매
                boolean success = coffeeShop.processOrder(customerOrder);

                if (success) {
                    System.out.println("주문이 완료되었습니다.");
                } else {
                    System.out.println("재료가 부족합니다!");
                    isGameOver = true;
                }
            }
        }
    }

    public void displayOrder(List<MenuItem> order) {
        System.out.println("손님 주문 내역:");
        int totalPrice = 0;
        for (MenuItem item : order) {
            System.out.println("- " + item.name + " (" + item.price + "원)");
            totalPrice += item.price;
        }
        System.out.println("총 금액: " + totalPrice + "원");
    }


    public boolean processCustomerMenu(List<MenuItem> order) {
        System.out.println("== 손님 메뉴 ===");
        System.out.println("1. 주문 확인하기");
        System.out.println("2. 주문 취소하기");
        System.out.print("선택: ");

        int choice = sc.nextInt();
        sc.nextLine();

        return choice == 2;
    }

    public void endDay() {
        System.out.println("=== " + currentDay + "일차 영업 종료 ===");
        System.out.println("오늘의 매출: " + coffeeShop.dailyRevenue + "원");
        System.out.println("현재 자금: " + coffeeShop.money + "원");

        // 일일 매출 초기화
        coffeeShop.resetDailyRevenue();

        System.out.println("계속하려면 엔터를 누르세요...");
        sc.nextLine();
    }

    public void showGameResult() {
        System.out.println("=== 게임 결과 ===");
        System.out.println("30일 동안 커피숍을 성공적으로 운영했습니다!");
        System.out.println("최종 자금: " + coffeeShop.money + "원");
        System.out.println("총 매출: " + coffeeShop.totalRevenue + "원");
    }

    public void askForRestart() {
        System.out.print("\n게임을 다시 시작하시겠습니까? (y/n): ");
        String answer = sc.nextLine();

        if (answer.equals("y")) {
            currentDay = 1;
            isGameOver = false;
            coffeeShop = new CoffeeShop();
            pendingDeliveries = new ArrayList<>();
            start();
        } else {
            System.out.println("게임을 종료합니다. 이용해주셔서 감사합니다!");
        }
    }

    public void selectWeather(){
        int weatherType = r.nextInt(6);
        todayWeather = new Weather(weatherType);
        System.out.println("오늘의 날씨: " + todayWeather.name);
    }
}

