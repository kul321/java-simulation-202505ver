package project.CoffeeShop;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class Customer {

    public static final Random r = new Random();

    public Customer() {

    }

    public List<MenuItem> order(List<MenuItem> availableMenu) {
        List<MenuItem> order = new ArrayList<>();

        if (availableMenu.isEmpty()) {
            return order;
        }


        // 음료와 음식 분리
        List<MenuItem> drinks = new ArrayList<>();
        List<MenuItem> foods = new ArrayList<>();

        for (MenuItem item : availableMenu) {
            if (item.type == MenuItem.DRINK) {
                drinks.add(item);
            } else if (item.type == MenuItem.FOOD) {
                foods.add(item);
            }
        }

        // 50% 확률로 음료 주문
        if (r.nextDouble() < 0.5 && !drinks.isEmpty()) {
            order.add(drinks.get(r.nextInt(drinks.size())));
        }

        // 30% 확률로 음식 주문
        if (r.nextDouble() < 0.3 && !foods.isEmpty()) {
            order.add(foods.get(r.nextInt(foods.size())));

        }

        return order;
    }
}