package project.CoffeeShop;

import java.util.List;

public class Satisfaction {
    public int satisfaction;

    // 최소/최대 만족도 제한
    public static final int MIN_SATISFACTION = 0;
    public static final int MAX_SATISFACTION = 100;

    public Satisfaction(){
        satisfaction = 50; //초기 만족도
    }

    // 주문 처리 시간에 따른 만족도 변화
    public int processSatisfaciton(double time, List<MenuItem> order){
       int result = (int)((1.0 - time/10)*40);
        System.out.println("주문처리시간에 따른"+result);
        //처리 시간에 따른 만족도 변화
        return result;
    }

    // 만족도에 따른 손님 배율 반환
    public double getCustomerMultiplier(){
        // 만족도가 50(기본값)일 때 배율이 1.0
        return 0.5 + (satisfaction / 100.0);
    }

    // 만족도 증가 (최대 100)
    public void increaseSatisfaction(int amount) {
        satisfaction += amount;
        if (satisfaction > MAX_SATISFACTION) {
            satisfaction = MAX_SATISFACTION;
        }
        System.out.println("만족도가 " + amount + "만큼 증가했습니다. 현재 만족도: " + satisfaction);
    }

    // 만족도 감소 (최소 0)
    public void decreaseSatisfaction(int amount) {
        satisfaction -= amount;
        if (satisfaction < MIN_SATISFACTION) {
            satisfaction = MIN_SATISFACTION;
        }
        System.out.println("만족도가 " + amount + "만큼 감소했습니다. 현재 만족도: " + satisfaction);
    }

    // 만족도가 0인지 확인 (게임오버 조건)
    public boolean isZero() {
        return satisfaction <= 0;
    }
}