package project.BookStore;

import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);
    //(2) BookRepository 클래스 만들고 객체 선언
    public static BookRepository bookRepository = new BookRepository();

    public static void main(String[] args) {

        //초기 데이터
        initializeData();
        boolean open = true;

        while (open) {
            displayMenu();
            int choice = sc.nextInt();
            sc.nextLine(); // 버퍼 비우기

            open = processMenuChoice(choice);
        }


    }


    public static void initializeData() {
        //예시 세 가지 책
        Book book1 = new Book("파이썬을 배워라! 당신의 파이가 늘어난다", 1, "한용영", "한영출판사", 2012, 5, 13000, 0);
        Book book2 = new Book("취미로 한 프로그래밍, 나의 주수입원이 되다", 2, "김미래", "나노출판사", 2017, 12, 15000, 0);
        Book book3 = new Book("자바야 걱정마 내가 너를 자바줄게", 3, "오아람", "날아라출판사", 2011, 3, 8000, 0);

        //(3) 책 3권 추가
        bookRepository.newBook(book1);
        bookRepository.newBook(book2);
        bookRepository.newBook(book3);
    }

    public static void displayMenu() {
        System.out.println("===서점 메뉴===");
        System.out.println("1. 전체 장서 목록 보기");
        System.out.println("2. 도서찾기");
        System.out.println("3. 도서 추가");
        System.out.println("4. 도서 판매하기");
        System.out.println("5. 도서 정보 수정하기");
        System.out.println("6. 출판사별 목록 보기");
        System.out.println("7. 재고별 목록 보기");
        System.out.println("8. 카테고리별 목록 보기");
        System.out.println("9. 도서 폐기");
        System.out.println("0. 종료");
        System.out.println("메뉴를 선택하세요.");
    }

    // 메뉴 선택 처리
    public static boolean processMenuChoice(int choice) {
        switch (choice) {
            case 1 -> showAllBooks();
            case 2 -> findBook();
            case 3 -> addNewBook();
            case 4 -> sellBook();
            case 5 -> updateBookInfo();
            case 6 -> showBooksByPublisher();
            case 7 -> showLowStockBooks();
            case 8 -> showBooksByCategory();
            case 9 -> removeBook();
            case 0 -> {
                System.out.println("프로그램을 종료합니다.");
                return false;
            }
            default -> System.out.println("잘못된 선택입니다. 다시 선택해주세요.");
        }
        return true;
    }

    // 1. 전체 책 목록 보기
    public static void showAllBooks() {
        bookRepository.allBook();
    }

    // 2. 책 찾기
    public static void findBook() {
        System.out.println("어떤 방식으로 책을 찾으시겠습니까?");
        System.out.println("1. 책 번호로");
        System.out.println("2. 제목으로");
        System.out.print("번호 입력: ");
        int searchChoice = sc.nextInt();
        sc.nextLine(); // 버퍼 비우기

        Book foundBook = null;

        if(searchChoice == 1) {
            System.out.print("책번호: ");
            int bookNumber = sc.nextInt();
            sc.nextLine(); // 버퍼 비우기
            foundBook = bookRepository.findBookByNum(bookNumber);
        } else if(searchChoice == 2) {
            System.out.print("책제목: ");
            String bookTitle = sc.nextLine();
            foundBook = bookRepository.findBookByTitle(bookTitle);
        } else {
            System.out.println("잘못된 선택입니다.");
            return;
        }

        if(foundBook != null) {
            foundBook.printInfo();
        } else {
            System.out.println("해당 책을 찾을 수 없습니다.");
        }
    }

    // 3. 새 책 추가
    public static void addNewBook() {
        System.out.println("===== 새 책 추가 =====");
        System.out.print("제목: ");
        String newTitle = sc.nextLine();

        System.out.print("책 번호: ");
        int newBookNumber = sc.nextInt();
        sc.nextLine();

        System.out.print("저자: ");
        String newAuthor = sc.nextLine();

        System.out.print("출판사: ");
        String newPublisher = sc.nextLine();

        System.out.print("출판년도: ");
        int newYear = sc.nextInt();
        sc.nextLine();

        System.out.print("초기 재고: ");
        int newStock = sc.nextInt();
        sc.nextLine();

        System.out.print("가격: ");
        int newPrice = sc.nextInt();
        sc.nextLine();

        System.out.println("카테고리 목록:");
        System.out.println("0: 총류");
        System.out.println("1: 철학");
        System.out.println("2: 종교");
        System.out.println("3: 사회과학");
        System.out.println("4: 자연과학");
        System.out.println("5: 기술과학");
        System.out.println("6: 예술");
        System.out.println("7: 언어");
        System.out.println("8: 문학");
        System.out.println("9: 역사");
        System.out.print("카테고리 코드(0-9): ");
        int newCategoryCode = sc.nextInt();
        sc.nextLine();

        Book newBook = new Book(newTitle, newBookNumber, newAuthor, newPublisher, newYear, newStock, newPrice, newCategoryCode);
        bookRepository.newBook(newBook);
    }


    // 4. 책 판매하기
    public static void sellBook() {
        System.out.println("===== 책 판매 =====");
        System.out.print("판매할 책 번호: ");
        int sellBookNumber = sc.nextInt();
        sc.nextLine();

        Book bookToSell = bookRepository.findBookByNum(sellBookNumber);
        if(bookToSell != null) {
            System.out.print("판매 수량: ");
            int sellQuantity = sc.nextInt();
            sc.nextLine();

            if(bookToSell.sellBook(sellQuantity)) {
                int totalPrice = bookToSell.calculateTotalPrice(sellQuantity);
                System.out.println("총 결제 금액: " + totalPrice + "원");
            }
        } else {
            System.out.println("해당 번호의 책을 찾을 수 없습니다.");
        }
    }

    // 5. 책 정보 수정하기
    public static void updateBookInfo() {
        System.out.println("===== 책 정보 수정 =====");
        System.out.print("수정할 책 번호: ");
        int updateBookNumber = sc.nextInt();
        sc.nextLine();

        Book bookToUpdate = bookRepository.findBookByNum(updateBookNumber);
        if(bookToUpdate != null) {
            System.out.println("현재 정보:");
            bookToUpdate.printInfo();

            System.out.println("수정할 항목을 선택하세요:");
            System.out.println("1. 제목");
            System.out.println("2. 저자");
            System.out.println("3. 가격");
            System.out.println("4. 카테고리");
            System.out.print("선택: ");
            int updateChoice = sc.nextInt();
            sc.nextLine();

            switch(updateChoice) {
                case 1 -> bookToUpdate.updateTitle();
                case 2 -> bookToUpdate.updateAuthor();
                case 3 -> bookToUpdate.updatePrice();
                case 4 -> bookToUpdate.updateCategory();
                default -> System.out.println("잘못된 선택입니다.");
            }
        } else {
            System.out.println("해당 번호의 책을 찾을 수 없습니다.");
        }
    }


    // 6. 출판사별 도서 목록
    public static void showBooksByPublisher() {
        bookRepository.booksByPublisher();
    }

    // 7. 재고 부족 도서 확인
    public static void showLowStockBooks() {
        bookRepository.lowStockBooks();
    }

    // 8. 카테고리별 도서 목록
    public static void showBooksByCategory() {
        bookRepository.booksByCategory();
    }

    // 9. 책 삭제하기
    public static void removeBook() {
        System.out.println("===== 책 삭제 =====");
        System.out.print("삭제할 책 번호: ");
        int removeBookNumber = sc.nextInt();
        sc.nextLine(); // 버퍼 비우기

        bookRepository.removeBook(removeBookNumber);
    }
}



