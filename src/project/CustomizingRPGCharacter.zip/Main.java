package project.CustomizingRPGCharacter;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Account account = null;

        while(account == null) {
            System.out.println("1. 회원가입");
            System.out.println("2. 로그인");
            System.out.print("선택: ");
            int choice = sc.nextInt();
            sc.nextLine();

            System.out.print("아이디: ");
            String id = sc.nextLine();
            System.out.print("비밀번호: ");
            String password = sc.nextLine();

            if(choice == 1) {
                // 회원가입
                if(Account.register(id, password)) {
                    account = Account.login(id, password);
                }
            } else if(choice == 2) {
                // 로그인
                account = Account.login(id, password);
            }
        }

        while(true) {
            System.out.println("\n1. 캐릭터 생성");
            System.out.println("2. 캐릭터 목록 보기");
            System.out.println("3. 능력치 찍기");
            System.out.println("4. 로그아웃");
            System.out.print("선택: ");
            int choice = sc.nextInt();
            sc.nextLine(); // 버퍼 비우기

            if(choice == 1) {
                // 캐릭터 생성
                System.out.print("캐릭터 이름: ");
                String characterName = sc.nextLine();

                System.out.println("\n사용 가능한 클래스:");
                System.out.println("1. 전사   2. 격투가   3. 창술가");
                System.out.println("4. 마법사  5. 궁수    6. 힐러");
                System.out.println("7. 정령사  8. 마검사   9. 마창사");
                System.out.print("클래스 선택(번호): ");
                int classChoice = sc.nextInt();

                if(classChoice < 1 || classChoice > 9) {
                    System.out.println("잘못된 클래스 선택입니다.");
                    continue;
                }

                String characterClass = "";
                switch(classChoice) {
                    case 1: characterClass = "전사"; break;
                    case 2: characterClass = "격투가"; break;
                    case 3: characterClass = "창술가"; break;
                    case 4: characterClass = "마법사"; break;
                    case 5: characterClass = "궁수"; break;
                    case 6: characterClass = "힐러"; break;
                    case 7: characterClass = "정령사"; break;
                    case 8: characterClass = "마검사"; break;
                    case 9: characterClass = "마창사"; break;
                }

                if(account.createCharacter(characterName, characterClass)) {
                    System.out.println("캐릭터가 생성되었습니다!");
                } else {
                    System.out.println("더 이상 캐릭터를 생성할 수 없습니다.");
                }
            }
            else if(choice == 2) {
                // 캐릭터 목록 보기
                if(account.characterCount == 0) {
                    System.out.println("생성된 캐릭터가 없습니다.");
                    continue;
                }
                account.displayAllCharacters();
            }
            else if(choice == 3) {
                // 능력치 찍기
                if(account.characterCount == 0) {
                    System.out.println("생성된 캐릭터가 없습니다.");
                    continue;
                }

                System.out.println("\n=== 능력치 찍기 ===");

                // 캐릭터 선택
                System.out.println("\n캐릭터 선택:");
                for(int i = 0; i < account.characterCount; i++) {
                    System.out.println((i+1) + ". " + account.characters[i].characterName
                            + " (" + account.characters[i].characterClass + ")");
                }
                System.out.print("선택: ");
                int charChoice = sc.nextInt();
                sc.nextLine();

                if(charChoice < 1 || charChoice > account.characterCount) {
                    System.out.println("잘못된 선택입니다.");
                    continue;
                }

                GameCharacter selectedChar = account.characters[charChoice-1];

                if (selectedChar.getRemainingSelectableStats() <= 0) {
                    System.out.println("더 이상 능력치를 선택할 수 없습니다!");
                    continue;
                }

                // 추천 능력치 표시
                selectedChar.displayRecommendedStats();

                // 사용 가능한 포인트와 남은 선택 가능 개수 표시
                System.out.println("\n현재 상태:");
                System.out.println("- 사용 가능한 포인트: " + selectedChar.availablePoints);
                System.out.println("- 남은 선택 가능 개수: " + selectedChar.getRemainingSelectableStats());
                System.out.println("(일반 능력치: 1포인트, 비주력 특수 능력치: 2포인트 소모)");
                System.out.println("===============================");

                // 능력치 선택
                System.out.println("\n능력치 선택:");
                System.out.println("1. 힘     2. 지능    3. HP      4. MP");
                System.out.println("5. 민첩   6. 운      7. 스피드");
                System.out.println("8. 검술   9. 궁술    10. 마검술");
                System.out.println("11. 마창술 12. 마법   13. 힐     14. 정령");
                System.out.print("선택: ");
                int statChoice = sc.nextInt();

                if(statChoice < 1 || statChoice > 14) {
                    System.out.println("잘못된 능력치 선택입니다.");
                    continue;
                }

                String statName = "";
                switch(statChoice) {
                    case 1: statName = "힘"; break;
                    case 2: statName = "지능"; break;
                    case 3: statName = "HP"; break;
                    case 4: statName = "MP"; break;
                    case 5: statName = "민첩"; break;
                    case 6: statName = "운"; break;
                    case 7: statName = "스피드"; break;
                    case 8: statName = "검술"; break;
                    case 9: statName = "궁술"; break;
                    case 10: statName = "마검술"; break;
                    case 11: statName = "마창술"; break;
                    case 12: statName = "마법"; break;
                    case 13: statName = "힐"; break;
                    case 14: statName = "정령"; break;
                }

                if(selectedChar.increaseStat(statName)) {
                    System.out.println("\n능력치가 증가되었습니다!");
                    selectedChar.displayCharacterInfo();
                } else {
                    System.out.println("\n포인트가 부족하거나 잘못된 선택입니다.");
                }
            }
            else if(choice == 4) {
                System.out.println("로그아웃 되었습니다.");
                break;
            }
            else {
                System.out.println("잘못된 선택입니다.");
            }
        }
        sc.close();
    }
}