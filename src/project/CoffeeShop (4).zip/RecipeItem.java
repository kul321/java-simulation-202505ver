package project.CoffeeShop;

public class RecipeItem {
    public String ingredientName;
    public int quantity;

    public RecipeItem(String ingredientName, int quantity) {
        this.ingredientName = ingredientName;
        this.quantity = quantity;
    }
}
