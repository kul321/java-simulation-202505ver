package project.Energy;

public class EnergyTransferManager {
    public boolean trnascferEnergy(Zone from, Zone to, double amount) {
        // 동맹 관계 체크 추가
        if(from.alliance == null || !from.isAlliedWith(to)) {
            System.out.println("동맹 관계가 아니어서 에너지를 전송할 수 없습니다.");
            return false;
        }

        if(amount > from.maxTransfer || amount > from.energy.amount) {
            System.out.println("전송 가능한 에너지량을 초과했습니다.");
            return false;
        }

        if(to.energy.amount + amount > to.energy.maxCapacity) {
            System.out.println("대상 구역의 최대 용량을 초과합니다.");
            return false;
        }

        // 전송
        from.energy.amount -= amount;
        to.energy.amount += amount;
        System.out.println("에너지 전송 완료: " + amount + " 단위");

        return true;
    }
}
