package project.Energy;


public class EnergyPool {
    public double storedEnergy;        // 저장된 에너지 (다음 턴까지 사용 불가)
    public double unstordEnergy;       // 미저장 에너지 (현재 턴에 사용 가능)
    public double maxCapacity;         // 에너지 풀의 최대 저장 가능 용량

    public EnergyPool(double maxCapacity) {
        this.maxCapacity = maxCapacity;
        this.storedEnergy = 0;
        this.unstordEnergy = 0;
    }


    //에너지 저장
    public boolean storeEnergy(double amount) {
        // 저장 조건 체크
        if (amount <= 0) {
            return false;
        }
        if (storedEnergy + amount > maxCapacity) {
            return false;
        }
        storedEnergy += amount;
        return true;
    }


    //턴 종료
    public void onTurnEnd() {
        // 미저장 에너지는 소멸
        unstordEnergy = 0;
        // 저장된 에너지를 미저장 상태로 변경
        unstordEnergy = storedEnergy;
        storedEnergy = 0;
    }


    //저장된 에너지 반환
    public double getStoredEnergy() {
        return storedEnergy;
    }


    //미저장 에너지 반환
    public double getUnstoredEnergy() {
        return unstordEnergy;
    }


    //최대 저장 가능 용량 반환
    public double getMaxCapacity() {
        return maxCapacity;
    }
}