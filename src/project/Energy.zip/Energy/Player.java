package project.Energy;

public class Player {
    public String name;
    public Zone zone;

    public Player(String name, Zone zone){
        this.name = name;
        this.zone = zone;
    }
}
