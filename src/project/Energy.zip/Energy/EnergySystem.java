package project.Energy;

public class EnergySystem {
    public Zone[] zones;
    public EnergyTransferManager transferManager;
    public EnergyPool energyPool;  // 추가

    public EnergySystem(int zoneCount){
        zones = new Zone[zoneCount];
        transferManager = new EnergyTransferManager();
        energyPool = new EnergyPool(1000);  // 초기 최대 용량 1000으로 설정
    }

    public boolean storeEnergy(Zone zone, double amount) {
        // 해당 구역이 가진 에너지보다 많이 저장하려고 하면 실패
        if(zone.energy.amount < amount) {
            System.out.println("보유한 에너지보다 많은 양을 저장할 수 없습니다.");
            return false;
        }

        // 풀에 저장 시도
        if(energyPool.storeEnergy(amount)) {
            zone.energy.amount -= amount;
            return true;
        } else {
            System.out.println("저장소의 최대 용량을 초과했습니다.");
            return false;
        }
    }

    // 저장된 에너지 사용 메서드
    public boolean useStoredEnergy(Zone zone, double amount) {
        if(energyPool.getStoredEnergy() < amount) {
            return false;
        }

        // 구역의 최대 용량 체크
        if(zone.energy.amount + amount > zone.energy.maxCapacity) {
            return false;
        }

        zone.energy.amount += amount;
        energyPool.storedEnergy -= amount;
        return true;
    }

    // 턴 종료시 호출되는 메서드
    public void onTurnEnd() {
        // 미저장 에너지 소멸
        energyPool.onTurnEnd();
        // 저장된 에너지를 미저장 상태로 변경
        energyPool.unstordEnergy = energyPool.storedEnergy;
        energyPool.storedEnergy = 0;
    }
}